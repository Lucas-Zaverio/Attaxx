#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <MLV/MLV_all.h>
#define TAILLE_PLATEAU 7
#define TAILLE_MAX_NOM 20

typedef struct{
    char nom[TAILLE_MAX_NOM];
    char symbol;
    int score;
} Joueur;

typedef struct{
    char plateau[TAILLE_PLATEAU+2][TAILLE_PLATEAU+2];
    Joueur *joueurs[2];
} Plateau;

void creationPlateau(Plateau *p){
    /*Cette fonction permet d'initaliser le plateau de base en entrant les différents caractères le composant: les délimites du terrain (*), 
    les espaces vides (.) et 2 pions de chaque joueurs a des postions précises.*/
    int i, j;
    for (i=0; i < TAILLE_PLATEAU+2 ; i++){
        for (j=0; j < TAILLE_PLATEAU+2 ;j++){
            if (i==0 || i==TAILLE_PLATEAU+1 || j==0 || j==TAILLE_PLATEAU+1)
                p->plateau[i][j] = '*';

            else if ((i==1 && j==1) || (i==TAILLE_PLATEAU && j==TAILLE_PLATEAU))
                p->plateau[i][j] = p->joueurs[0]->symbol;

            else if ((i==1 && j==TAILLE_PLATEAU) || (i==TAILLE_PLATEAU && j==1))
                p->plateau[i][j] = p->joueurs[1]->symbol;
            
            else   
                p->plateau[i][j] = '.';
        }
    }
}

void affichePlateau(Plateau p){
    /*Permet d'afficher le plateau en utilisant les caractères présents dans le tableau à deux dimensions de la structure plateau. 
    (Les modifications du plateau sont pris en compte)*/
    int i,j;
    for (i=0; i < TAILLE_PLATEAU+2 ; i++){
        for (j=0; j < TAILLE_PLATEAU+2 ;j++){
            printf("%c ",p.plateau[i][j]);
        }
        printf("\n");
    }
}

void afficheGraphique(Plateau p){
    int i,j;
    for (i=0; i < TAILLE_PLATEAU+2; i++){
        for (j=0; j < TAILLE_PLATEAU+2; j++){
            if ((i==0) || (i==TAILLE_PLATEAU+1) || (j==0) || (j==TAILLE_PLATEAU+1))
                MLV_draw_rectangle(50*i, 50*j, 50, 50, MLV_COLOR_BLACK);
            else
                MLV_draw_rectangle(50*i, 50*j, 50, 50, MLV_COLOR_WHITE);
        }
    }
    for (i=0; i < TAILLE_PLATEAU+2; i++){
        for (j=0; j < TAILLE_PLATEAU+2; j++){
            if (p.plateau[i][j] == p.joueurs[0]->symbol)
                MLV_draw_text(50*i+25, 50*j+25, &(p.joueurs[0]->symbol), MLV_COLOR_BLUE);
            else if (p.plateau[i][j] == p.joueurs[1]->symbol)
               MLV_draw_text(50*i+25, 50*j+25, &(p.joueurs[1]->symbol), MLV_COLOR_RED);
        }
    }
    MLV_actualise_window();
}


int coupValideJ1(Plateau *p, int li, int col){
    /*Cette fonction est décomposé en 2 parties, tout d'abord elle vérifie si le pion est bien posé sur un espace libre représenté par un point,
    si cela n'est pas le cas, elle retourne 0.
    Ensuite, elle vérifie si dans le carré autour de ce pion il y'a au minimum 1 pion adverse, si c'est le cas elle retourne 1 sinon elle retourne 0 
    Par exemple si une personne joue en [0][1] ou le joueur 2 joue en [1][1] qui est occupé par un pion du joueur 1, la fonction retournera 0.*/
    if (p->plateau[li][col] != '.'){
        return 0;
    }
    else{
        for (int i=li-1; i<=li+1; i++){
            for (int j=col-1; j<=col+1; j++){
                if (p->plateau[i][j] == p->joueurs[1]->symbol){
                    p->plateau[li][col] = p->joueurs[0]->symbol;
                    p->joueurs[0]->score += 1;
                    return 1;
                }
            }
        }
        return 0;
    }
}

int coupValideJ2(Plateau *p, int li, int col){
    //Même chose que la fonction précédente mais pour le joueur n.2
    if (p->plateau[li][col] != '.'){
        return 0;
    }
    else{
        for (int i=li-1; i<=li+1; i++){
            for (int j=col-1; j<=col+1; j++){
                if (p->plateau[i][j] == p->joueurs[0]->symbol){
                    p->plateau[li][col] = p->joueurs[1]->symbol;
                    p->joueurs[1]->score += 1;
                    return 1;
                }
            }
        }
        return 0;
    }
}

int FinJeu(Plateau p){
    /*Cette fonction permet de vérifier les conditions d'arrêt du jeu: 
    -Si un des deux scores est égal à 0, alors l'autre joueur est déclaré vainqueur.
    -Sinon il regarde s'il reste un espace libre dans le plateau auquel cas la fonction retourne 0, si c'est pas le cas et donc que toutes les cases sont 
    occupés par un des deux pions adverse, selon le résultat à la fin 3 valeurs sont retournés:
    1 si le joueur 1 gagne, 2 si le joueur 2 gagne, 3 s'il y'a égalité.*/
    if (p.joueurs[1]->score == 0){
        return 1;
    }
    else if (p.joueurs[0]->score == 0){
        return 2;
    }
    else{
        for (int i=1; i<=TAILLE_PLATEAU; i++){
            for (int j=1; j<=TAILLE_PLATEAU; j++){
                if (p.plateau[i][j] == '.')
                    return 0;
            }
        }
        if (p.joueurs[0]->score > p.joueurs[1]->score){
            return 1;
        }
        else if (p.joueurs[0]->score < p.joueurs[1]->score){
            return 2;
        }
        else{
            return 3;
        }
    }
}

int main(int argc, char *argv[]){
    if (argv[1][1] == 'a'){
        //Si le premier argument après le tiret est la lettre a, l'affichage se fera donc en ascii.
        if (argv[2][1] == 'h'){
            //Si le second argument après le tiret est la lettre h, deux joueurs pourront s'affronter.
            Joueur J1; 
            Joueur J2;
            Plateau jeu;
            //Nous créeons les joueurs ainsi que le plateau.
            /*-----------------------------------------------------------------------------------*/
            printf("Quel est le nom du premier joueur (symbol o): ");
            scanf(" %s",J1.nom);
            J1.symbol = 'o';
            J1.score = 2;
            //Initialisation du joueur 1
            /*-----------------------------------------------------------------------------------*/
            printf("Quel est le nom du deuxième joueur (symbol x): ");
            scanf(" %s",J2.nom);
            J2.symbol = 'x';
            J2.score = 2; 
            //Initialisation du joueur 2
            /*-----------------------------------------------------------------------------------*/
            jeu.joueurs[0] = &J1; //Permet de remplir le tableau de joueurs (qui est un pointeur d'où l'utilisation du '&') du plateau avec toutes les données remplies précédemment
            jeu.joueurs[1] = &J2;
            printf("\n");
            printf("Les règles du jeu ATTAX:\nPour poser un pion, il suffit d'écrire la coordonnée ligne et colonne de votre pion en respectant 2 règles:\nVotre pion doit-être posé sur une case libre (.) et un pion adverse doit se situer dans le carrée autour des coordonnées de là ou voulez placer votre pion.\n");
            printf("Le but pour gagner est:\nSoit en réduisant le score de l'adversaire à 0 (en éliminant ses pions grâce à la pose des votres), soit d'avoir le plus de points lorsqu'aucun pion est possible d'être posé. Amusez-vous bien !\n\n");
            int res1, res2, l, m, li, col;
            /*l et m représentent les valeurs de retour des coups valides pour les joueurs. 
            La coordonné ligne est représenté par li et la coordonnée colonne est représenté par col*/
            /*-----------------------------------------------------------------------------------*/
            creationPlateau(&jeu);
            affichePlateau(jeu);
            //Initialisation et affichage du plateau d'origine
            printf("\n");
            do {
                do{
                    printf("%s (%c), veuillez saisir les coordonnées où jouer (entre 1 et 7) : ",jeu.joueurs[0]->nom,jeu.joueurs[0]->symbol);
                    scanf(" %d %d",&li,&col);
                    l = coupValideJ1(&jeu, li, col); 
                } while (l == 0); //Cette boucle me permet de contrôler que le placement du pion est valide, auquel cas le joueur devra de nouveau inscrire ses coordonnés
                jeu.plateau[li][col] = jeu.joueurs[0]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[1]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[0]->symbol;
                        jeu.joueurs[0]->score += 1;
                        jeu.joueurs[1]->score -= 1; 
                        } //Cette boucle permet de gérer les changements de pions dans le plateau ainsi que le score qui évoluera selon les pions changés
                    }
                }
                affichePlateau(jeu);
                printf("Score actuel : %s(%c) %d - %s(%c) %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->symbol, jeu.joueurs[0]->score ,jeu.joueurs[1]->nom, jeu.joueurs[1]->symbol, jeu.joueurs[1]->score);
                res1 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res1 == 1){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
                else if(res1 == 2){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[1]->nom, jeu.joueurs[1]->score, jeu.joueurs[0]->score);
                    return 0;
                }
                else if(res1 == 3){
                    printf("Egalité ! %d à %d\n",jeu.joueurs[0]->score,jeu.joueurs[1]->score);
                    return 0;
                }
                /*-----------------------------------------------------------------------------------*/
                do{
                    printf("%s (%c), veuillez saisir les coordonnées où jouer (entre 1 et 7) : ",jeu.joueurs[1]->nom,jeu.joueurs[1]->symbol);
                    scanf(" %d %d",&li,&col);
                    m = coupValideJ2(&jeu, li, col);
                } while (m == 0);
                jeu.plateau[li][col] = jeu.joueurs[1]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[0]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[1]->symbol;
                        jeu.joueurs[0]->score -= 1;
                        jeu.joueurs[1]->score += 1;
                        }
                    }
                }
                affichePlateau(jeu);
                printf("Score actuel : %s(%c) %d - %s(%c) %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->symbol, jeu.joueurs[0]->score ,jeu.joueurs[1]->nom, jeu.joueurs[1]->symbol, jeu.joueurs[1]->score);
                res2 = FinJeu(jeu);
                if(res2 == 1){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
                else if(res2 == 2){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[1]->nom, jeu.joueurs[1]->score, jeu.joueurs[0]->score);
                    return 0;
                }
                else if(res2 == 3){
                    printf("Egalité ! %d à %d\n",jeu.joueurs[0]->score,jeu.joueurs[1]->score);
                    return 0;
                }
            } while ((res1 == 0) && (res2 == 0));
        }
        else if (argv[2][1] == 'o'){
            //Si le second argument après le tiret est la lettre o, le joueur affrontera l'ordi.
            srand(time(NULL));
            Joueur J1;
            Joueur Ordi;
            Plateau jeu;
            //Nous créeons les joueurs ainsi que le plateau.
            /*-----------------------------------------------------------------------------------*/
            printf("Quel est le nom du premier joueur (symbol o): ");
            scanf(" %s",J1.nom);
            J1.symbol = 'o';
            J1.score = 2;
            //Initialisation du joueur 1
            /*-----------------------------------------------------------------------------------*/
            Ordi.symbol = 'x';
            strcpy(Ordi.nom, "IA");
            Ordi.score = 2;
            //Initialisation de l'ordinateur
            /*-----------------------------------------------------------------------------------*/
            jeu.joueurs[0] = &J1;
            jeu.joueurs[1] = &Ordi;
            printf("\n");
            printf("Les règles du jeu ATTAX:\nPour poser un pion, il suffit d'écrire la coordonnée ligne et colonne de votre pion en respectant 2 règles:\nVotre pion doit-être posé sur une case libre (.) et un pion adverse doit se situer dans le carrée autour des coordonnées de là ou voulez placer votre pion.\n");
            printf("Le but pour gagner est:\nSoit en réduisant le score de l'adversaire à 0 (en éliminant ses pions grâce à la pose des votres), soit d'avoir le plus de points lorsqu'aucun pion est possible d'être posé. Amusez-vous bien !\n");
            int res1, res2, l, m, li, col, liO, colO; 
            /*l et m représentent les valeurs de retour des coups valides pour le joueur et l'ordinateur. 
            La coordonné ligne est représenté par li et liO(pour l'ordinateur) et la coordonnée colonne est représenté par col et colO(pour l'ordinateur)*/
            /*-----------------------------------------------------------------------------------*/
            creationPlateau(&jeu);
            affichePlateau(jeu);
            //Création et initialisation du plateau.
            do {
                printf("\n\n");
                do{
                    printf("%s (%c), veuillez saisir les coordonnées où jouer (entre 1 et 7) : ",jeu.joueurs[0]->nom,jeu.joueurs[0]->symbol);
                    scanf(" %d %d",&li,&col);
                    l = coupValideJ1(&jeu, li, col);
                } while (l == 0); //Cette boucle me permet de contrôler que le placement du pion est valide, auquel cas le joueur devra de nouveau inscrire ses coordonnés
                jeu.plateau[li][col] = jeu.joueurs[0]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[1]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[0]->symbol;
                        jeu.joueurs[0]->score += 1;
                        jeu.joueurs[1]->score -= 1; 
                        } //Cette boucle permet de gérer les changements de pions dans le plateau ainsi que le score qui évoluera selon les pions changés
                    }
                }
                affichePlateau(jeu);
                printf("Score actuel : %s(%c) %d - %s(%c) %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->symbol, jeu.joueurs[0]->score ,jeu.joueurs[1]->nom, jeu.joueurs[1]->symbol, jeu.joueurs[1]->score);
                res1 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res1 == 1){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
                else if(res1 == 2){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[1]->nom, jeu.joueurs[1]->score, jeu.joueurs[0]->score);
                    return 0;
                }
                else if(res1 == 3){
                    printf("Egalité ! %d à %d\n",jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
                /*-----------------------------------------------------------------------------------*/
                printf("\n\n");
                printf("L'%s (%c), est entrain de jouer...\n",jeu.joueurs[1]->nom, jeu.joueurs[1]->symbol);
                do{
                    liO = rand()%7+1;
                    colO = rand()%7+1;
                    m = coupValideJ2(&jeu, liO, colO);
                } while (m == 0); 
                /*C'est le même principe qu'avec le joueur qui entre les coordonnées mais ici pour jouer l'ordi va choisir des nombres aléatoirement
                les coordonnées et de la même manière qu'un joueur classique, si les coordonnés donnent un mouvement pas valide, alors ça recommencera
                (à noter que le placement des pions n'est pas faite de manière intelligente)*/
                printf("Le coup de l'ordi est : %d %d\n",liO,colO);
                jeu.plateau[liO][colO] = jeu.joueurs[1]->symbol;
                for (int i=liO-1; i<=liO+1; i++){
                    for (int j=colO-1; j<=colO+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[0]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[1]->symbol;
                        jeu.joueurs[0]->score -= 1;
                        jeu.joueurs[1]->score += 1;
                        }
                    }
                }
                affichePlateau(jeu);
                printf("Score actuel : %s(%c) %d - %s(%c) %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->symbol, jeu.joueurs[0]->score ,jeu.joueurs[1]->nom, jeu.joueurs[1]->symbol, jeu.joueurs[1]->score);
                res2 = FinJeu(jeu);
                if(res2 == 1){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[0]->nom, jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
                else if(res2 == 2){
                    printf("Bravo %s, vous avez gagné %d à %d\n",jeu.joueurs[1]->nom, jeu.joueurs[1]->score, jeu.joueurs[0]->score);
                    return 0;
                }
                else if(res2 == 3){
                    printf("Egalité ! %d à %d\n",jeu.joueurs[0]->score, jeu.joueurs[1]->score);
                    return 0;
                }
            } while ((res1 == 0) && (res2 == 0));
        }
        return 0;
    }
    else if(argv[1][1] == 'g'){
        //Si le premier argument après le tiret est g, la version graphique du jeu s'ouvrira alors.
        if (argv[2][1] == 'h'){
            Joueur J1;
            Joueur J2;
            Plateau jeu;
            /*-----------------------------------------------------------------------------------*/
            MLV_create_window("Attax", "Attax", 1000, 1000);
            MLV_draw_text(10, 0, "Bienvenue sur le jeu ATTAX, vous avez choisi de jouer avec un ami !", MLV_COLOR_RED1);
            MLV_draw_text(10, 50, "Quel est le nom du premier joueur (symbol o): ", MLV_COLOR_RED1);
            MLV_actualise_window();
            scanf(" %s",J1.nom);
            J1.symbol = 'o';
            J1.score = 2;
            MLV_draw_text(450, 50, J1.nom, MLV_COLOR_RED1);
            MLV_actualise_window();
            /*-----------------------------------------------------------------------------------*/
            MLV_draw_text(10, 100, "Quel est le nom du second joueur (symbol x): ", MLV_COLOR_RED1);
            MLV_actualise_window();
            scanf(" %s",J2.nom);
            J2.symbol = 'x';
            J2.score = 2;
            MLV_draw_text(450, 100, J2.nom, MLV_COLOR_RED1);
            MLV_actualise_window();
            /*-----------------------------------------------------------------------------------*/
            jeu.joueurs[0] = &J1;
            jeu.joueurs[1] = &J2;
            /*-----------------------------------------------------------------------------------*/
            int res1, res2, l, m, li, col;
            MLV_clear_window(MLV_COLOR_BLACK);
            creationPlateau(&jeu);
            afficheGraphique(jeu);
            do {
                MLV_clear_window(MLV_COLOR_BLACK);
                afficheGraphique(jeu);
                do{
                    MLV_draw_text(10, 10, "Joueur 1, a vous de jouer !", MLV_COLOR_RED);
                    MLV_wait_mouse(&li, &col);
                    li = (int)li/50; //Ici diviser la valeur pat 50 me permet d'avoir la coordonnée du pion par rapport a notre structure plateau
                    col = (int)col/50;
                    l = coupValideJ1(&jeu, li, col);
                } while (l == 0); //Cette boucle me permet de contrôler que le placement du pion est valide, auquel cas le joueur devra de nouveau inscrire ses coordonnés
                jeu.plateau[li][col] = jeu.joueurs[0]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[1]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[0]->symbol;
                        jeu.joueurs[0]->score += 1;
                        jeu.joueurs[1]->score -= 1; 
                        } //Cette boucle permet de gérer les changements de pions dans le plateau ainsi que le score qui évoluera selon les pions changés
                    }
                }
                afficheGraphique(jeu);
                res1 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res1 == 1){
                    MLV_draw_text(10, 450, "Bravo Joueur 1 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res1 == 2){
                    MLV_draw_text(10, 450, "Bravo Joueur 2 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res1 == 3){
                    MLV_draw_text(10, 450, "Beau combat, mais c'est une égalité !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                /*-----------------------------------------------------------------------------------*/
                MLV_clear_window(MLV_COLOR_BLACK);
                afficheGraphique(jeu);
                do{
                    MLV_draw_text(10, 10, "Joueur 2, a vous de jouer !", MLV_COLOR_RED);
                    MLV_wait_mouse(&li, &col);
                    li = (int)li/50;
                    col = (int)col/50;
                    m = coupValideJ2(&jeu, li, col);
                } while (m == 0); 
                jeu.plateau[li][col] = jeu.joueurs[1]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[0]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[1]->symbol;
                        jeu.joueurs[0]->score -= 1;
                        jeu.joueurs[1]->score += 1;
                        }
                    }
                }
                afficheGraphique(jeu);
                res2 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res2 == 1){
                    MLV_draw_text(10, 450, "Bravo Joueur 1 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res2 == 2){
                    MLV_draw_text(10, 450, "Bravo Joueur 2 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res2 == 3){
                    MLV_draw_text(10, 450, "Beau combat, mais c'est une égalité !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                MLV_clear_window(MLV_COLOR_BLACK);
                afficheGraphique(jeu);
                MLV_wait_seconds(1);
            } while ((res1 == 0) && (res2 == 0));
        }
        else if (argv[2][1] == 'o'){
            Joueur J1;
            Joueur Ordi;
            Plateau jeu;
            /*-----------------------------------------------------------------------------------*/
            MLV_create_window("Attax", "Attax", 1000, 1000);
            MLV_draw_text(10, 0, "Bienvenue sur le jeu ATTAX, vous avez choisi de jouer avec un ami !", MLV_COLOR_RED1);
            MLV_draw_text(10, 50, "Quel est le nom du premier joueur (symbol o): ", MLV_COLOR_RED1);
            MLV_actualise_window();
            scanf(" %s",J1.nom);
            J1.symbol = 'o';
            J1.score = 2;
            MLV_draw_text(350, 50, J1.nom, MLV_COLOR_RED1);
            MLV_actualise_window();
            /*-----------------------------------------------------------------------------------*/
            strcpy(Ordi.nom, "IA");
            Ordi.symbol = 'x';
            Ordi.score = 2;
            /*-----------------------------------------------------------------------------------*/
            jeu.joueurs[0] = &J1;
            jeu.joueurs[1] = &Ordi;
            int res1, res2, l, m, li, col;
            /*-----------------------------------------------------------------------------------*/
            MLV_clear_window(MLV_COLOR_BLACK);
            creationPlateau(&jeu);
            afficheGraphique(jeu);
            /*-----------------------------------------------------------------------------------*/
            do {
                MLV_clear_window(MLV_COLOR_BLACK);
                afficheGraphique(jeu);
                do{
                    MLV_draw_text(10, 10, "Joueur 1, a vous de jouer !", MLV_COLOR_RED);
                    MLV_wait_mouse(&li, &col);
                    li = (int)li/50; //Ici diviser la valeur pat 50 me permet d'avoir la coordonnée du pion par rapport a notre structure plateau
                    col = (int)col/50;
                    l = coupValideJ1(&jeu, li, col);
                } while (l == 0); //Cette boucle me permet de contrôler que le placement du pion est valide, auquel cas le joueur devra de nouveau inscrire ses coordonnés
                jeu.plateau[li][col] = jeu.joueurs[0]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[1]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[0]->symbol;
                        jeu.joueurs[0]->score += 1;
                        jeu.joueurs[1]->score -= 1; 
                        } //Cette boucle permet de gérer les changements de pions dans le plateau ainsi que le score qui évoluera selon les pions changés
                    }
                }
                afficheGraphique(jeu);
                res1 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res1 == 1){
                    MLV_draw_text(10, 450, "Bravo Joueur 1 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res1 == 2){
                    MLV_draw_text(10, 450, "Bravo Joueur 2 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res1 == 3){
                    MLV_draw_text(10, 450, "Beau combat, mais c'est une égalité !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                /*-----------------------------------------------------------------------------------*/
                MLV_clear_window(MLV_COLOR_BLACK);
                afficheGraphique(jeu);
                do{
                    MLV_draw_text(10, 10, "L'ordi joue.. ", MLV_COLOR_RED);
                    li = rand()%7+1;
                    col = rand()%7+1;
                    m = coupValideJ2(&jeu, li, col);
                } while (m == 0); 
                jeu.plateau[li][col] = jeu.joueurs[1]->symbol;
                for (int i=li-1; i<=li+1; i++){
                    for (int j=col-1; j<=col+1; j++){
                        if (jeu.plateau[i][j] == jeu.joueurs[0]->symbol){
                        jeu.plateau[i][j] = jeu.joueurs[1]->symbol;
                        jeu.joueurs[0]->score -= 1;
                        jeu.joueurs[1]->score += 1;
                        }
                    }
                }
                afficheGraphique(jeu);
                res2 = FinJeu(jeu); //La valeur de retour de cette fonction me permet de savoir si un cas de victoire est atteint, si cela est le cas le jeu s'arrête sinon il continue
                if(res2 == 1){
                    MLV_draw_text(10, 450, "Bravo Joueur 1 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res2 == 2){
                    MLV_draw_text(10, 450, "Bravo Joueur 2 ! Tu as gagné la partie !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
                else if(res2 == 3){
                    MLV_draw_text(10, 450, "Beau combat, mais c'est une égalité !", MLV_COLOR_RED);
                    MLV_actualise_window();
                    MLV_wait_seconds(10);
                    MLV_free_window();
                    return 0;
                }
            } while ((res1 == 0) && (res2 == 0));
        }
    }
}
